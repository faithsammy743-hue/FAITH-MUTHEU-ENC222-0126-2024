#include <iostream>
using namespace std;
int main() {
    // Define an array of integers
    int numbers[5] = {2, 5, 7, 8, 15};

    // Iterate through the array (for loop)
    for (int i = 0; i < 5; i++) {
        // Selection statement (if-else)
        if (numbers[i] % 2 == 0) {
            cout << "Even number: " << numbers[i] << '\n';
        } else {
            cout << "Odd number: " << numbers[i] << '\n';
        }
    };
    return 0;
    
}